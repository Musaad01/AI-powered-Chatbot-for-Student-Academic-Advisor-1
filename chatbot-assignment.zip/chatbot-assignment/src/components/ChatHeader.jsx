import React from "react";

const ChatHeader = () => {
  return (
    <header className="chat-header">
      <h2>Chat with Bot</h2>
    </header>
  );
};

export default ChatHeader;
